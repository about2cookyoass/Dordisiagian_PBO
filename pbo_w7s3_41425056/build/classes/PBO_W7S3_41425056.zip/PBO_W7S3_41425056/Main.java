/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;

import java.time.LocalDate;
import java.util.NoSuchElementException;



/*
Nama : Dordiasina Siagian
Nim : 411425056
*/


// Class driver: menjalankan program dan memanggil semua method
public class Main {

    public static void main(String[] args) {
        // acuan umur: tanggal hari ini
        Validator validator = new Validator(LocalDate.of(2026, 10, 23));
        // objek bioskop
        Bioskop bioskop = new Bioskop(validator);

        // membuat 4 film dengan rating umur berbeda
        Film kancil = new Film("Petualangan Si Kancil", 0);
        Film rumahTua = new Film("Misteri Rumah Tua", 13);
        Film balapan = new Film("Balapan Maut", 17);
        Film malam = new Film("Malam Tanpa Akhir", 21);

        // membuat jadwal: studio 2 baris x 4 kolom, J5 khusus perempuan
        bioskop.tambahJadwal(new Jadwal("J1", kancil, "10:00", false, 2, 4));
        bioskop.tambahJadwal(new Jadwal("J2", rumahTua, "13:00", false, 2, 4));
        bioskop.tambahJadwal(new Jadwal("J3", balapan, "16:00", false, 2, 4));
        bioskop.tambahJadwal(new Jadwal("J4", malam, "19:00", false, 2, 4));
        bioskop.tambahJadwal(new Jadwal("J5", rumahTua, "21:00", true, 2, 4));
        bioskop.tampilkanJadwal();
        System.out.println("===");

        // registrasi: 3 valid dan beberapa gagal
        bioskop.registrasi("P001", "Ana Pertiwi", "2005-03-14", "P");
        bioskop.registrasi("P002", "Budi Santoso", "2012-05-01", "L");
        bioskop.registrasi("P003", "Citra Dewi", "2008-09-09", "p");
        bioskop.registrasi("P004", "Dedi Kurnia", "10-08-2004", "L");
        bioskop.registrasi("P005", "Eka Putri", "2004-01-01", "X");
        bioskop.registrasi("P006", "", "2004-01-01", "L");
        bioskop.registrasi("P007", "Fajar Nugroho", "1990-01-01", "L");
        bioskop.registrasi("P008", "Gita Lestari", "2030-01-01", "P");
        bioskop.registrasi("P001", "Ana Lagi", "2005-03-14", "P");
        System.out.println("===");

        // pemesanan normal: film semua umur
        bioskop.pesan("P001", "J1", "A1");
        // kursi sama dipesan lagi
        bioskop.pesan("P003", "J1", "A1");
        // kode kursi di luar studio
        bioskop.pesan("P003", "J1", "Z9");
        // umur 14 tahun memesan film 17+
        bioskop.pesan("P002", "J3", "A1");
        // umur 14 tahun memesan film 13+, boleh
        bioskop.pesan("P002", "J2", "B1");
        // penonton laki-laki memesan pemutaran khusus perempuan
        bioskop.pesan("P007", "J5", "A1");
        // penonton perempuan memesan pemutaran yang sama, boleh
        bioskop.pesan("P001", "J5", "A1");
        // penonton atau jadwal yang tidak ada
        bioskop.pesan("P999", "J1", "A2");
        bioskop.pesan("P001", "J9", "A2");

        // riwayat tidak hadir: tiga kali tidak hadir lalu coba memesan lagi
        bioskop.catatTidakHadir("P007");
        bioskop.catatTidakHadir("P007");
        bioskop.catatTidakHadir("P007");
        bioskop.pesan("P007", "J1", "A2");

        // penjualan jadwal ditutup lalu dibuka lagi
        Jadwal j3 = bioskop.cariJadwal("J3");
        j3.tutup();
        bioskop.pesan("P003", "J3", "A1");
        j3.buka();
        // setelah dibuka, penonton 18 tahun boleh memesan film 17+
        bioskop.pesan("P003", "J3", "A1");
        System.out.println("===");

        // menampilkan jadwal dan riwayat setelah semua pemesanan
        bioskop.tampilkanJadwal();
        bioskop.tampilkanRiwayat("P001");
        bioskop.tampilkanRiwayat("P007");
        System.out.println("===");

        // membaca data penonton lewat semua getter
        Penonton p = bioskop.cariPenonton("P001");
        System.out.println("Kartu: " + p.getId() + ", " + p.getNama() + ", lahir " + p.getTanggalLahir()
                + ", gender " + p.getGender() + ", umur " + p.getUmur()
                + ", tidak hadir " + p.getTidakHadir() + "x, riwayat " + p.getRiwayat().size());

        // membaca data jadwal lewat semua getter
        Jadwal j5 = bioskop.cariJadwal("J5");
        System.out.println("Jadwal: " + j5.getKode() + ", " + j5.getFilm().getJudul()
                + " (" + j5.getFilm().getRatingUmur() + " tahun), jam " + j5.getJam()
                + ", khusus perempuan " + j5.isKhususWanita() + ", sisa kursi " + j5.getSisaKursi());

        // mencari penonton yang tidak ada, memicu NoSuchElementException
        try {
            bioskop.cariPenonton("P404");
        } catch (NoSuchElementException e) {
            System.out.println("Gagal cari: " + e.getMessage());
        }

        // memanggil cekAkses langsung: method ber-throws, jadi dibungkus try-catch
        try {
            bioskop.cariJadwal("J4").cekAkses(bioskop.cariPenonton("P003"));
        } catch (UmurTidakCukupException e) {
            System.out.println("Cek langsung: umur " + e.getUmur() + ", batas " + e.getBatas());
        } catch (PemesananDitolakException e) {
            System.out.println("Cek langsung: " + e.getAlasan());
        }

        // memanggil pesanKursi langsung: kursi A1 di J1 sudah terisi
        try {
            bioskop.cariJadwal("J1").pesanKursi("A1");
        } catch (KursiTidakTersediaException | DataTidakValidException e) {
            System.out.println("Kursi langsung gagal: " + e.getMessage());
        }

        // memanggil validator langsung
        try {
            validator.cekNama("Hadi Wijaya");
            validator.cekTanggalLahir("2000-01-01");
            System.out.println("Gender 'p' menjadi " + validator.cekGender("p")
                    + ", umur lahir 2000-01-01 = " + validator.hitungUmur(LocalDate.of(2000, 1, 1)));
        } catch (DataTidakValidException e) {
            System.out.println("Validator langsung gagal: " + e.getMessage());
        }
    }
}