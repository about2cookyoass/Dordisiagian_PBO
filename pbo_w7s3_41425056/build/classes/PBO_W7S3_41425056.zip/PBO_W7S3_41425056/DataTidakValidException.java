/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;
/*
Nama : Dordiasina Siagian
Nim : 411425056
*/

// Exception buatan sendiri: dilempar saat data input tidak sesuai aturan
// extends Exception artinya checked exception (wajib ditangani atau dideklarasikan throws)
public class DataTidakValidException extends Exception {

    // menyimpan nama kolom yang salah, misalnya "gender" atau "kursi"
    private String kolom;

    // constructor: menerima nama kolom dan alasan kesalahan
    public DataTidakValidException(String kolom, String alasan) {
        // memanggil constructor Exception dengan pesan error
        super("Data " + kolom + " tidak valid: " + alasan);
        // menyimpan nama kolom ke atribut
        this.kolom = kolom;
    }

    // mengambil nama kolom yang salah
    public String getKolom() {
        return kolom;
    }
}
