/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;


/*
Nama : Dordiasina Siagian
Nim : 411425056
*/



// Exception buatan sendiri turunan PemesananDitolakException: kursi sudah dipesan orang lain
public class KursiTidakTersediaException extends PemesananDitolakException {

    // kode kursi yang bermasalah
    private String kode;

    // constructor: menerima kode kursi
    public KursiTidakTersediaException(String kode) {
        // memanggil constructor induk dengan alasan
        super("kursi " + kode + " sudah terisi");
        this.kode = kode;
    }

    // mengambil kode kursi
    public String getKode() {
        return kode;
    }
}
