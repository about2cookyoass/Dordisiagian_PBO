/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;

import java.time.LocalDate;
import java.time.Period;


/*
Nama : Dordiasina Siagian
Nim : 411425056
*/



// Class Validator: memeriksa data pendaftaran penonton
public class Validator {

    // tanggal hari ini sebagai acuan menghitung umur
    private LocalDate hariIni;

    // constructor: mengisi tanggal acuan
    public Validator(LocalDate hariIni) {
        this.hariIni = hariIni;
    }

    // memeriksa nama: tidak kosong, hanya huruf dan spasi
    public void cekNama(String nama) throws DataTidakValidException {
        // throw: nama kosong
        if (nama == null || nama.trim().isEmpty()) {
            throw new DataTidakValidException("nama", "tidak boleh kosong");
        }
        // throw: ada karakter selain huruf dan spasi
        if (!nama.matches("[A-Za-z ]+")) {
            throw new DataTidakValidException("nama", "hanya boleh huruf dan spasi");
        }
    }

    // memeriksa gender: hanya L atau P, lalu mengembalikannya sebagai char
    public char cekGender(String gender) throws DataTidakValidException {
        // throw: gender bukan L atau P
        if (gender == null || !(gender.equalsIgnoreCase("L") || gender.equalsIgnoreCase("P"))) {
            throw new DataTidakValidException("gender", "harus L atau P");
        }
        // mengubah ke huruf besar lalu mengambil karakter pertama
        return gender.toUpperCase().charAt(0);
    }

    // LocalDate.parse melempar DateTimeParseException jika format salah (unchecked)
    public LocalDate cekTanggalLahir(String teks) throws DataTidakValidException {
        // mengubah teks menjadi tanggal
        LocalDate lahir = LocalDate.parse(teks);
        // throw: tanggal lahir tidak boleh setelah hari ini
        if (lahir.isAfter(hariIni)) {
            throw new DataTidakValidException("tanggal lahir", "tidak boleh di masa depan");
        }
        return lahir;
    }

    // menghitung umur pada tanggal acuan
    public int hitungUmur(LocalDate lahir) {
        return Period.between(lahir, hariIni).getYears();
    }
}