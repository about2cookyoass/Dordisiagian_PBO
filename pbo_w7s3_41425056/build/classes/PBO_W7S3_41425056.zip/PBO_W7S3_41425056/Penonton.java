/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


/*
Nama : Dordiasina Siagian
Nim : 411425056
*/



// Class Penonton: data pelanggan beserta riwayat menonton dan tidak hadir
public class Penonton {

    // id pelanggan
    private String id;
    // nama lengkap
    private String nama;
    // tanggal lahir
    private LocalDate tanggalLahir;
    // gender: 'L' atau 'P'
    private char gender;
    // umur pada hari ini
    private int umur;
    // jumlah pemesanan yang tidak dihadiri
    private int tidakHadir;
    // daftar riwayat pemesanan
    private List<String> riwayat = new ArrayList<>();

    // constructor: mengisi data dasar penonton
    public Penonton(String id, String nama, LocalDate tanggalLahir, char gender, int umur) {
        this.id = id;
        this.nama = nama;
        this.tanggalLahir = tanggalLahir;
        this.gender = gender;
        this.umur = umur;
        // penonton baru belum pernah tidak hadir
        this.tidakHadir = 0;
    }

    // mengambil id
    public String getId() {
        return id;
    }

    // mengambil nama
    public String getNama() {
        return nama;
    }

    // mengambil tanggal lahir
    public LocalDate getTanggalLahir() {
        return tanggalLahir;
    }

    // mengambil gender
    public char getGender() {
        return gender;
    }

    // mengambil umur
    public int getUmur() {
        return umur;
    }

    // mengambil jumlah tidak hadir
    public int getTidakHadir() {
        return tidakHadir;
    }

    // mencatat satu kali tidak hadir
    public void catatTidakHadir() {
        tidakHadir++;
    }

    // menambah satu baris riwayat pemesanan
    public void tambahRiwayat(String catatan) {
        riwayat.add(catatan);
    }

    // mengambil seluruh riwayat
    public List<String> getRiwayat() {
        return riwayat;
    }
}