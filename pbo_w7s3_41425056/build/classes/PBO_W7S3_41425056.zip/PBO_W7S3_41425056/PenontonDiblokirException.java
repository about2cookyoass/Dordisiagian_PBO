/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;


/*
Nama : Dordiasina Siagian
Nim : 411425056
*/



// Exception buatan sendiri turunan PemesananDitolakException: riwayat tidak hadir terlalu banyak
public class PenontonDiblokirException extends PemesananDitolakException {

    // jumlah riwayat tidak hadir
    private int tidakHadir;

    // constructor: menerima jumlah tidak hadir
    public PenontonDiblokirException(int tidakHadir) {
        // memanggil constructor induk dengan alasan
        super("riwayat tidak hadir " + tidakHadir + " kali, akun diblokir");
        this.tidakHadir = tidakHadir;
    }

    // mengambil jumlah tidak hadir
    public int getTidakHadir() {
        return tidakHadir;
    }
}
