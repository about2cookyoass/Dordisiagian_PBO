/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;



/*
Nama : Dordiasina Siagian
Nim : 411425056
*/



// Exception buatan sendiri: induk untuk semua alasan pemesanan tiket ditolak
public class PemesananDitolakException extends Exception {

    // menyimpan alasan penolakan
    private String alasan;

    // constructor: menerima alasan penolakan
    public PemesananDitolakException(String alasan) {
        // memanggil constructor Exception dengan pesan error
        super("Pemesanan ditolak: " + alasan);
        // menyimpan alasan ke atribut
        this.alasan = alasan;
    }

    // mengambil alasan penolakan
    public String getAlasan() {
        return alasan;
    }
}
