/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;


/*
Nama : Dordiasina Siagian
Nim : 411425056
*/


// Exception buatan sendiri turunan PemesananDitolakException: umur di bawah rating film
public class UmurTidakCukupException extends PemesananDitolakException {

    // umur penonton
    private int umur;
    // batas umur minimal film
    private int batas;

    // constructor: menerima umur penonton dan batas umur film
    public UmurTidakCukupException(int umur, int batas) {
        // memanggil constructor induk dengan alasan
        super("umur " + umur + " tahun, film ini untuk " + batas + " tahun ke atas");
        this.umur = umur;
        this.batas = batas;
    }

    // mengambil umur penonton
        public int getUmur() {
            return umur;
    }

    // mengambil batas umur film
    public int getBatas() {
        return batas;
    }
}
