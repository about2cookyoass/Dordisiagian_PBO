/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;

import java.util.LinkedHashSet;
import java.util.Set;



/*
Nama : Dordiasina Siagian
Nim : 411425056
*/



// Class Jadwal: satu sesi tayang lengkap dengan kursi dan aturan akses
public class Jadwal {

    // batas jumlah tidak hadir sebelum penonton diblokir
    private static final int BATAS_TIDAK_HADIR = 3;

    // kode jadwal, misalnya J1
    private String kode;
    // film yang tayang
    private Film film;
    // jam tayang
    private String jam;
    // true jika pemutaran khusus penonton perempuan
    private boolean khususWanita;
    // jumlah baris dan kolom kursi
    private int baris;
    private int kolom;
    // status penjualan tiket, true berarti dibuka
    private boolean dibuka;
    // kode kursi yang sudah terisi
    private Set<String> kursiTerisi = new LinkedHashSet<>();

    // constructor: mengisi semua data jadwal
    public Jadwal(String kode, Film film, String jam, boolean khususWanita, int baris, int kolom) {
        this.kode = kode;
        this.film = film;
        this.jam = jam;
        this.khususWanita = khususWanita;
        this.baris = baris;
        this.kolom = kolom;
        // penjualan awal dalam keadaan dibuka
        this.dibuka = true;
    }

    // mengambil kode jadwal
    public String getKode() {
        return kode;
    }

    // mengambil film
    public Film getFilm() {
        return film;
    }

    // mengambil jam tayang
    public String getJam() {
        return jam;
    }

    // mengecek apakah pemutaran khusus perempuan
    public boolean isKhususWanita() {
        return khususWanita;
    }

    // mengambil jumlah kursi yang masih kosong
    public int getSisaKursi() {
        return baris * kolom - kursiTerisi.size();
    }

    // menutup penjualan tiket
    public void tutup() {
        dibuka = false;
    }

    // membuka penjualan tiket
    public void buka() {
        dibuka = true;
    }

    // memeriksa apakah penonton boleh memesan jadwal ini
    // throws: pemanggil harus menangani PemesananDitolakException atau turunannya
    public void cekAkses(Penonton p) throws PemesananDitolakException {
        // throw: penjualan tiket sedang ditutup
        if (!dibuka) {
            throw new IllegalStateException("Penjualan jadwal " + kode + " sudah ditutup");
        }
        // throw: riwayat tidak hadir mencapai batas
        if (p.getTidakHadir() >= BATAS_TIDAK_HADIR) {
            throw new PenontonDiblokirException(p.getTidakHadir());
        }
        // throw: umur di bawah rating film
        if (p.getUmur() < film.getRatingUmur()) {
            throw new UmurTidakCukupException(p.getUmur(), film.getRatingUmur());
        }
        // throw: pemutaran khusus perempuan tetapi penonton bukan perempuan
        if (khususWanita && p.getGender() != 'P') {
            throw new PemesananDitolakException("pemutaran ini khusus penonton perempuan");
        }
    }

    // memesan satu kursi berdasarkan kode, misalnya A1
    public void pesanKursi(String kodeKursi) throws KursiTidakTersediaException, DataTidakValidException {
        // menyusun pola kode yang diizinkan, contoh A sampai B dan 1 sampai 4
        char barisAkhir = (char) ('A' + baris - 1);
        String pola = "[A-" + barisAkhir + "][1-" + kolom + "]";
        // throw: format kode kursi salah
        if (kodeKursi == null || !kodeKursi.matches(pola)) {
            throw new DataTidakValidException("kursi", "kode harus A1 sampai " + barisAkhir + kolom);
        }
        // throw: kursi sudah dipesan
        if (kursiTerisi.contains(kodeKursi)) {
            throw new KursiTidakTersediaException(kodeKursi);
        }
        // kursi aman, catat sebagai terisi
        kursiTerisi.add(kodeKursi);
    }
}