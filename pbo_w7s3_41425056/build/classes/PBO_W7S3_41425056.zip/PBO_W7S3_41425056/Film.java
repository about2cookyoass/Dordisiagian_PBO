/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;



/*
Nama : Dordiasina Siagian
Nim : 411425056
*/

// Class Film: menyimpan judul dan batas umur penonton
public class Film {

    // judul film
    private String judul;
    // batas umur minimal, 0 berarti semua umur
    private int ratingUmur;

    // constructor: mengisi judul dan rating umur
    public Film(String judul, int ratingUmur) {
        this.judul = judul;
        this.ratingUmur = ratingUmur;
    }

    // mengambil judul
    public String getJudul() {
        return judul;
    }

    // mengambil batas umur
    public int getRatingUmur() {
        return ratingUmur;
    }

    // mengubah batas umur menjadi label seperti yang tertulis di tiket
    public String getLabelRating() {
        // rating 0 berarti film untuk semua umur (SU)
        if (ratingUmur == 0) {
            return "SU";
        }
        return ratingUmur + "+";
    }
}