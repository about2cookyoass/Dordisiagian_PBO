/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w7s3_41425056;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

// Class Bioskop: mengelola jadwal, pendaftaran penonton, dan pemesanan tiket
public class Bioskop {

    // objek pemeriksa data
    private Validator validator;
    // daftar jadwal tayang
    private List<Jadwal> daftarJadwal = new ArrayList<>();
    // daftar penonton terdaftar
    private List<Penonton> daftarPenonton = new ArrayList<>();

    // constructor: menerima validator
    public Bioskop(Validator validator) {
        this.validator = validator;
    }

    // menambah jadwal tayang
    public void tambahJadwal(Jadwal jadwal) {
        daftarJadwal.add(jadwal);
    }

    // mencari jadwal berdasarkan kode
    public Jadwal cariJadwal(String kode) {
        for (Jadwal j : daftarJadwal) {
            if (j.getKode().equals(kode)) {
                return j;
            }
        }
        // throw: kode jadwal tidak ditemukan
        throw new NoSuchElementException("Jadwal " + kode + " tidak ditemukan");
    }

    // mencari penonton berdasarkan id
    public Penonton cariPenonton(String id) {
        for (Penonton p : daftarPenonton) {
            if (p.getId().equals(id)) {
                return p;
            }
        }
        // throw: id penonton tidak ditemukan
        throw new NoSuchElementException("Penonton " + id + " tidak ditemukan");
    }

    // mendaftarkan penonton baru dari data mentah berupa teks
    public void registrasi(String id, String nama, String tglLahir, String gender) {
        // try: blok yang kemungkinan menimbulkan exception
        try {
            // memeriksa id ganda
            for (Penonton p : daftarPenonton) {
                if (p.getId().equals(id)) {
                    throw new DataTidakValidException("id", "sudah terdaftar");
                }
            }
            // memeriksa data satu per satu
            validator.cekNama(nama);
            char g = validator.cekGender(gender);
            LocalDate lahir = validator.cekTanggalLahir(tglLahir);
            int umur = validator.hitungUmur(lahir);
            // semua valid, simpan penonton
            daftarPenonton.add(new Penonton(id, nama, lahir, g, umur));
            // baris ini hanya jalan jika tidak ada exception
            System.out.println("REGISTRASI OK: " + id + " " + nama + " (" + umur + " th, " + g + ")");
        } catch (DataTidakValidException e) {
            // catch: data tidak valid, tampilkan kolom yang salah
            System.out.println("REGISTRASI GAGAL [" + e.getKolom() + "]: " + e.getMessage());
        } catch (DateTimeParseException e) {
            // catch: format tanggal salah, getParsedString berisi teks yang dimasukkan
            System.out.println("REGISTRASI GAGAL: format tanggal harus yyyy-MM-dd, input '" + e.getParsedString() + "'");
        } finally {
            // finally: selalu dijalankan, ada exception atau tidak
            System.out.println("Total penonton terdaftar: " + daftarPenonton.size());
            System.out.println("---");
        }
    }

    // memproses pemesanan tiket
    public void pesan(String idPenonton, String kodeJadwal, String kodeKursi) {
        // try: blok yang kemungkinan menimbulkan exception
        try {
            // mencari penonton dan jadwal (bisa melempar NoSuchElementException)
            Penonton p = cariPenonton(idPenonton);
            Jadwal j = cariJadwal(kodeJadwal);
            // memeriksa hak akses: riwayat, umur, gender, status jadwal
            j.cekAkses(p);
            // memesan kursi
            j.pesanKursi(kodeKursi);
            // mencatat ke riwayat penonton
            p.tambahRiwayat(j.getFilm().getJudul() + " " + j.getJam() + " kursi " + kodeKursi);
            // baris ini hanya jalan jika tidak ada exception
            System.out.println("TIKET OK: " + p.getNama() + " | " + j.getFilm().getJudul()
                    + " (" + j.getFilm().getLabelRating() + ") | " + j.getJam() + " | kursi " + kodeKursi);
        } catch (UmurTidakCukupException e) {
            // catch: umur kurang, ditaruh sebelum induknya agar tidak tertutup
            System.out.println("DITOLAK (umur " + e.getUmur() + ", batas " + e.getBatas() + "): " + e.getMessage());
        } catch (PenontonDiblokirException e) {
            // catch: riwayat tidak hadir terlalu banyak
            System.out.println("DITOLAK (tidak hadir " + e.getTidakHadir() + "x): " + e.getMessage());
        } catch (KursiTidakTersediaException e) {
            // catch: kursi sudah terisi
            System.out.println("DITOLAK (kursi " + e.getKode() + "): " + e.getMessage());
        } catch (PemesananDitolakException e) {
            // catch: alasan penolakan lainnya, misalnya khusus perempuan
            System.out.println("DITOLAK: " + e.getAlasan());
        } catch (DataTidakValidException e) {
            // catch: kode kursi salah format
            System.out.println("DITOLAK [" + e.getKolom() + "]: " + e.getMessage());
        } catch (NoSuchElementException | IllegalStateException e) {
            // catch: data tidak ditemukan atau penjualan ditutup
            System.out.println("DITOLAK: " + e.getMessage());
        } finally {
            // finally: selalu dijalankan, ada exception atau tidak
            System.out.println("---");
        }
    }

    // mencatat penonton tidak hadir di jadwal yang sudah dipesan
    public void catatTidakHadir(String idPenonton) {
        // mencari penonton lalu menambah hitungan tidak hadir
        Penonton p = cariPenonton(idPenonton);
        p.catatTidakHadir();
    }

    // menampilkan semua jadwal beserta sisa kursi
    public void tampilkanJadwal() {
        System.out.println("Jadwal tayang:");
        for (Jadwal j : daftarJadwal) {
            // menandai pemutaran khusus perempuan
            String khusus = j.isKhususWanita() ? " [khusus perempuan]" : "";
            System.out.println(j.getKode() + " | " + j.getFilm().getJudul() + " ("
                    + j.getFilm().getLabelRating() + ") | " + j.getJam() + khusus
                    + " | sisa kursi " + j.getSisaKursi());
        }
    }

    // menampilkan riwayat pemesanan satu penonton
    public void tampilkanRiwayat(String idPenonton) {
        Penonton p = cariPenonton(idPenonton);
        System.out.println("Riwayat " + p.getNama() + " (tidak hadir " + p.getTidakHadir() + "x):");
        // jika kosong, beri tahu
        if (p.getRiwayat().isEmpty()) {
            System.out.println("(belum ada riwayat)");
        }
        // mencetak setiap riwayat dengan nomor urut
        int no = 1;
        for (String r : p.getRiwayat()) {
            System.out.println(no + ". " + r);
            no++;
        }
    }
}